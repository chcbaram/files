# -*- coding: utf-8 -*-
#
#     ||          ____  _ __
#  +------+      / __ )(_) /_______________ _____  ___
#  | 0xBC |     / __  / / __/ ___/ ___/ __ `/_  / / _ \
#  +------+    / /_/ / / /_/ /__/ /  / /_/ / / /_/  __/
#   ||  ||    /_____/_/\__/\___/_/   \__,_/ /___/\___/
#
#  Copyright (C) 2014 Bitcraze AB
#
#  Crazyflie Nano Quadcopter Client
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA  02110-1301, USA.
"""
Simple example that scans for available Crazyflies and lists them.
"""
"""
Modified for OpenCR
"""



import logging
import os
import usb
import re
import sys
import threading
import time
import signal



__author__ = 'ROBOTIS'
__all__ = ['CrUsb']

logger = logging.getLogger(__name__)

if sys.version_info < (3,):
    import Queue as queue
else:
    import queue


USB_VID = 0x0483
USB_PID = 0x5740


try:
    import usb.core

    pyusb_backend = None
    if os.name == 'nt':
        import usb.backend.libusb0 as libusb0

        pyusb_backend = libusb0.get_backend()
    pyusb1 = True
except:
    pyusb1 = False


def _find_devices():
    """
    Returns a list of CrazyRadio devices currently connected to the computer
    """
    ret = []

    logger.info('Looking for devices....')

    if pyusb1:
        for d in usb.core.find(idVendor=USB_VID, idProduct=USB_PID, find_all=1,
                               backend=pyusb_backend):
            ret.append(d)
    else:
        busses = usb.busses()
        for bus in busses:
            for device in bus.devices:
                if device.idVendor == USB_VID:
                    if device.idProduct == USB_PID:
                        ret += [device, ]

    return ret


class CrUsb:
    """ Used for communication with the OpenCR """

    def __init__(self, device=None, devid=0):
        """ Create object and scan for USB if no device is supplied """
        self.dev = None
        self.handle = None
        self._last_write = 0
        self._last_read = 0

        if device is None:
            devices = _find_devices()
            try:
                self.dev = devices[devid]
            except Exception:
                self.dev = None

        if self.dev:
            #print(self.dev)
            if (pyusb1 is True):
                self.dev.reset()
                if self.dev.is_kernel_driver_active(0) == True:
                    self.dev.detach_kernel_driver(0)

                self.dev.set_configuration()
                self.handle = self.dev
                self.version = float(
                    '{0:x}.{1:x}'.format(self.dev.bcdDevice >> 8,
                                         self.dev.bcdDevice & 0x0FF))
                print(self.version)
            else:
                self.handle = self.dev.open()
                self.handle.setConfiguration(1)
                self.handle.claimInterface(0)
                self.version = float(self.dev.deviceVersion)

    def get_serial(self):
        # The signature for get_string has changed between versions to 1.0.0b1,
        # 1.0.0b2 and 1.0.0. Try the old signature first, if that fails try
        # the newer one.
        try:
            return usb.util.get_string(self.dev, 255, self.dev.iSerialNumber)
        except (usb.core.USBError, ValueError):
            return usb.util.get_string(self.dev, self.dev.iSerialNumber)

    def get_product(self):
        try:
            return usb.util.get_string(self.dev, 255, self.dev.iProduct)
        except (usb.core.USBError, ValueError):
            return usb.util.get_string(self.dev, self.dev.iProduct)

    def close(self):
        if (pyusb1 is False):
            if self.handle:
                self.handle.releaseInterface()
                self.handle.reset()
        else:
            if self.dev:
                self.dev.reset()

        self.handle = None
        self.dev = None

    def scan(self):
        # TODO: Currently only supports one device
        if self.dev:
            return [('usb://0', '')]
        return []

    def set_cdc_open(self):
            _send_control(self.handle, 0x22, 0x01, 1, (1))

    # Data transfers
    def send_packet(self, dataOut):
        """ Send a packet and receive the ack from the radio dongle
            The ack contains information about the packet transmition
            and a data payload if the ack packet contained any """
        try:
            if (pyusb1 is False):
                self.handle.bulkWrite(1, dataOut, 20)
            else:
                self.handle.write(endpoint=1, data=dataOut, timeout=20)
                print('send')
        except usb.USBError:
            print('send err')
            pass

    def receive_packet(self):
        dataIn = ()
        try:
            if (pyusb1 is False):
                dataIn = self.handle.bulkRead(0x81, 64, 20)
            else:
                #dataIn = self.handle.read(0x81, 64, timeout=20)
                dataIn = self.handle.read(0x81, 1024*4, timeout=100)


        except usb.USBError as e:
            try:
                if e.backend_error_code == -7 or e.backend_error_code == -116:
                    # Normal, the read was empty
                    pass
                else:
                    raise IOError('Crazyflie disconnected')
            except AttributeError as e:
                # pyusb < 1.0 doesn't implement getting the underlying error
                # number and it seems as if it's not possible to detect
                # if the cable is disconnected. So this detection is not
                # supported, but the "normal" case will work.
                pass

        return dataIn


# Private utility functions
def _send_control(handle, request, value, index, data):
    if pyusb1:
        handle.ctrl_transfer(0x22, request, wValue=value, wIndex=index, timeout=1000, data_or_wLength=data)
    else:
        handle.controlMsg(0x22, request, data, value=value,  index=index, timeout=1000)





class CrUsbDriver():
    """ OpenCR usb driver """

    def __init__(self):
        """ Create the link driver """
        self.crusb = None
        self.uri = ''
        self.in_queue = None
        self.out_queue = None
        self._thread = None
        self.needs_resending = False

    def connect(self, uri):


        self.uri = uri

        if self.crusb is None:
            self.crusb = CrUsb()
            if self.crusb.dev:
                self.crusb.set_cdc_open()
            else:
                self.crusb = None
                raise Exception('Could not open {}'.format(self.uri))

        else:
            raise Exception('Link already open!')

        # Prepare the inter-thread communication queue
        self.in_queue = queue.Queue(1024*1024)
        # Limited size out queue to avoid "ReadBack" effect
        self.out_queue = queue.Queue(50)

        # Launch the comm thread
        self._thread = _UsbReceiveThread(self.crusb, self.in_queue)
        self._thread.start()


    def receive_packet(self, time=0):
        """
        Receive a packet though the link. This call is blocking but will
        timeout and return None if a timeout is supplied.
        """
        if time == 0:
            try:
                return self.in_queue.get(False)
            except queue.Empty:
                return None
        elif time < 0:
            try:
                return self.in_queue.get(True)
            except queue.Empty:
                return None
        else:
            try:
                return self.in_queue.get(True, time)
            except queue.Empty:
                return None

    def send_packet(self, pk):
        """ Send the packet pk though the link """
        # if self.out_queue.full():
        #    self.out_queue.get()
        if (self.crusb is None):
            return

        try:
            dataOut = pk
            self.crusb.send_packet(dataOut)
        except queue.Full:
            print('CrUsbDriver: Could not send packet to OpenCR')

    def pause(self):
        self._thread.stop()
        self._thread = None

    def restart(self):
        if self._thread:
            return

        self._thread = _UsbReceiveThread(self.crusb, self.in_queue,
                                         self.link_quality_callback,
                                         self.link_error_callback)
        self._thread.start()

    def close(self):
        """ Close the link. """
        # Stop the comm thread
        self._thread.stop()

        # Close the USB dongle
        try:
            if self.crusb:
                self.crusb.set_crtp_to_usb(False)
                self.crusb.close()
        except Exception as e:
            # If we pull out the dongle we will not make this call
            logger.info('Could not close {}'.format(e))
            pass
        self.crusb = None

    def scan_interface(self, address):
        """ Scan interface for Crazyflies """
        if self.crusb is None:
            try:
                self.crusb = crusb()
            except Exception as e:
                logger.warn(
                    'Exception while scanning for OpenCR USB: {}'.format(
                        str(e)))
                return []
        else:
            raise Exception('Cannot scan for links while the link is open!')

        # FIXME: implements serial number in the Crazyradio driver!
        # serial = "N/A"

        found = self.crusb.scan()

        self.crusb.close()
        self.crusb = None

        return found

    def get_status(self):
        return 'No information available'

    def get_name(self):
        #return 'UsbCdc'
        if self.crusb:
            return self.crusb.get_product()
        else:
            return 'CrUsbCdc'


# Transmit/receive radio thread
class _UsbReceiveThread(threading.Thread):
    """
    Radio link receiver thread used to read data from the
    OpenCR USB driver. """

    # RETRYCOUNT_BEFORE_DISCONNECT = 10

    def __init__(self, crusb, inQueue):
        """ Create the object """
        threading.Thread.__init__(self)
        self.crusb = crusb
        self.in_queue = inQueue
        self.sp = False

        signal.signal(signal.SIGINT, self.txStopRequest)


    def txStopRequest(self, signal, frame):
        stop()


    def stop(self):
        """ Stop the thread """
        self.sp = True
        try:
            self.join()
        except Exception:
            pass

    def run(self):
        """ Run the receiver thread """

        while (True):
            if (self.sp):
                break
            try:
                # Blocking until USB data available
                data = self.crusb.receive_packet()
                if len(data) > 0:
                    #pk = CRTPPacket(data[0], list(data[1:]))
                    #self.in_queue.put(pk)
                    for i in data:
                        self.in_queue.put(i)
                    #print(data)

            except Exception as e:
                import traceback

                print(
                    'Error communicating with the OpenCR'
                    ' ,it has probably been unplugged!\n'
                    'Exception:%s\n\n%s' % (e,
                                            traceback.format_exc()))




def as_byte_array(string):
    return sab([ord(x) for x in string])  # XXX will require adaption when run with a 3.x compatible IronPython


class Serial():

    BAUDRATES = (50, 75, 110, 134, 150, 200, 300, 600, 1200, 1800, 2400, 4800,
                 9600, 19200, 38400, 57600, 115200)

    def __init__(self):
        """ Create the link driver """
        self.crusb = CrUsbDriver()
        self.crusb.connect('OpenCR');
        print("Found OpenCR")
        print(self.crusb.get_name())

        signal.signal(signal.SIGINT, self.txStopRequest)


    def txStopRequest(self, signal, frame):
        #self.port.close()
        self.crusb.close()
    def open(self):
        print("OpenCR Open")
        pass

    def _reconfigure_port(self):
        pass

    def close(self):
        """Close port"""
        self.crusb.close()


    def inWaiting(self):
        return self.crusb.in_queue.qsize();

    #  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

    @property
    def in_waiting(self):
        """Return the number of characters currently in the input buffer."""
        return 0

    def read(self, size=1):
        """\
        Read size bytes from the serial port. If a timeout is set it may
        return less characters as requested. With no timeout it will block
        until the requested number of bytes is read.
        """
        data = bytearray()

        while size:
            try:

                #print(data)
                #data = self.crusb.receive_packet(1)
                #data.append(self._port_handle.ReadByte())
                if self.crusb.in_queue.qsize() > 0:
                    data.append(self.crusb.receive_packet(1))
                else:
                    continue
                #print(data)
            except System.TimeoutException:
                break
            else:
                size -= 1

        return bytes(data)

    def write(self, data):
        """Output the given string over the serial port."""
        print("Write")
        print(data)

        if self.crusb.crusb is None:
            return
        #~ if not isinstance(data, (bytes, bytearray)):
            #~ raise TypeError('expected %s or bytearray, got %s' % (bytes, type(data)))
        try:
            # must call overloaded method with byte array argument
            # as this is the only one not applying encodings
            #self._port_handle.Write(as_byte_array(data), 0, len(data))
            #self.crusb.send_packet(as_byte_array(data))
            self.crusb.send_packet(data)
        except Exception:
            #raise writeTimeoutError
            print("write error")


        return len(data)

    def reset_input_buffer(self):
        """Clear input buffer, discarding all that is in the buffer."""
        pass

    def reset_output_buffer(self):
        """\
        Clear output buffer, aborting the current output and
        discarding all that is in the buffer.
        """
        pass

    def _update_break_state(self):
        """
        Set break: Controls TXD. When active, to transmitting is possible.
        """
        pass

    def _update_rts_state(self):
        """Set terminal status line: Request To Send"""
        pass

    def _update_dtr_state(self):
        """Set terminal status line: Data Terminal Ready"""
        pass

    @property
    def cts(self):
        """Read terminal status line: Clear To Send"""
        pass

    @property
    def dsr(self):
        """Read terminal status line: Data Set Ready"""
        pass

    @property
    def ri(self):
        """Read terminal status line: Ring Indicator"""
        return False  # XXX an error would be better

    @property
    def cd(self):
        """Read terminal status line: Carrier Detect"""
        return False

    # - - platform specific - - - -
    # none

    def flushInput(self):
        pass



if __name__ == "__main__":
    crusb = CrUsbDriver()


    crusb.connect('OpenCR')
    data = { 0x00, 0x01 }

    print(crusb.get_name())

    crusb.send_packet(data)

    try:
        """
        in_data = input()
        if in_data:
            crusb.close()
        """
    except Exception:
        crusb.close()
